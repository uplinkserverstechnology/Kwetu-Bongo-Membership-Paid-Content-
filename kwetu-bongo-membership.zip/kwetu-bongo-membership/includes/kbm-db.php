<?php
if (!defined('ABSPATH')) exit;

class KBM_DB {
    public static function table($suffix){
        global $wpdb;
        return $wpdb->prefix . 'kbm_' . $suffix;
    }
}
