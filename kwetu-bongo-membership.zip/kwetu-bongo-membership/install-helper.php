<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
require_once ABSPATH . 'wp-admin/includes/upgrade.php';

$charset = $wpdb->get_charset_collate();

$memberships = $wpdb->prefix . 'kbm_memberships';
$subscriptions = $wpdb->prefix . 'kbm_subscriptions';
$transactions = $wpdb->prefix . 'kbm_transactions';

$sql1 = "CREATE TABLE {$memberships} (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT(20) UNSIGNED NOT NULL,
  membership_type VARCHAR(100) NOT NULL,
  status VARCHAR(50) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY status (status)
) {$charset};";

$sql2 = "CREATE TABLE {$subscriptions} (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT(20) UNSIGNED NOT NULL,
  plan_id VARCHAR(100) NOT NULL,
  status VARCHAR(50) DEFAULT 'active',
  billing_cycle VARCHAR(50) DEFAULT 'monthly',
  renewal_date DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY status (status)
) {$charset};";

$sql3 = "CREATE TABLE {$transactions} (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT(20) UNSIGNED NOT NULL,
  subscription_id BIGINT(20) UNSIGNED NOT NULL,
  order_id VARCHAR(191) NOT NULL,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(10) NOT NULL DEFAULT 'USD',
  payment_gateway VARCHAR(50) NOT NULL DEFAULT 'manual',
  status VARCHAR(50) NOT NULL DEFAULT 'completed',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY subscription_id (subscription_id),
  KEY status (status)
) {$charset};";

dbDelta($sql1);
dbDelta($sql2);
dbDelta($sql3);

// default options
if (false === get_option('kbm_version')) add_option('kbm_version', '1.0.26');
if (false === get_option('kbm_install_date')) add_option('kbm_install_date', current_time('mysql'));
