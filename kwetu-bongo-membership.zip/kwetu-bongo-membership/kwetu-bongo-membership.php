<?php
/**
 * Plugin Name: Kwetu Bongo Membership
 * Plugin URI: https://kwetubongo.co.tz/demo.html
 * Description: Kwetu Bongo Membership / Paid Content is a WordPress membership and paid content system that allows website owners, bloggers, and digital publishers to restrict specific posts, pages, or custom content and make them available only to subscribed members.
 * Version: 1.0.26
 * Author: Uplink Servers Technology
 * Author URI: https://servers.co.tz
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: kwetu-bongo-membership
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) exit;

// Load textdomain
add_action('plugins_loaded', function(){
    load_plugin_textdomain('kwetu-bongo-membership', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

// Activation: create DB tables & default options
register_activation_hook(__FILE__, function() {
    include plugin_dir_path(__FILE__) . 'install-helper.php';
});

// Admin menu (top-level)
add_action('admin_menu', function(){
    add_menu_page(
        __('Kwetu Bongo Membership', 'kwetu-bongo-membership'),
        __('Kwetu Bongo Membership', 'kwetu-bongo-membership'),
        'manage_options',
        'kbm_dashboard',
        'kbm_dashboard_page',
        'dashicons-groups',
        56
    );
    add_submenu_page('kbm_dashboard', __('Dashboard','kwetu-bongo-membership'), __('Dashboard','kwetu-bongo-membership'), 'manage_options', 'kbm_dashboard', 'kbm_dashboard_page');
    add_submenu_page('kbm_dashboard', __('Memberships','kwetu-bongo-membership'), __('Memberships','kwetu-bongo-membership'), 'manage_options', 'kbm_memberships', 'kbm_memberships_page');
    add_submenu_page('kbm_dashboard', __('Subscriptions','kwetu-bongo-membership'), __('Subscriptions','kwetu-bongo-membership'), 'manage_options', 'kbm_subscriptions', 'kbm_subscriptions_page');
    add_submenu_page('kbm_dashboard', __('Transactions','kwetu-bongo-membership'), __('Transactions','kwetu-bongo-membership'), 'manage_options', 'kbm_transactions', 'kbm_transactions_page');
    add_submenu_page('kbm_dashboard', __('Settings','kwetu-bongo-membership'), __('Settings','kwetu-bongo-membership'), 'manage_options', 'kbm_settings', 'kbm_settings_page');
});

// Simple dashboard & placeholders
function kbm_dashboard_page(){
    global $wpdb;
    $m = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}kbm_memberships'") ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}kbm_memberships") : 0;
    $s = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}kbm_subscriptions'") ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}kbm_subscriptions") : 0;
    $t = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}kbm_transactions'") ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}kbm_transactions") : 0;
    echo '<div class="wrap"><h1>Kwetu Bongo Membership — Dashboard</h1>';
    echo '<p><strong>Memberships:</strong> ' . esc_html($m) . '</p>';
    echo '<p><strong>Subscriptions:</strong> ' . esc_html($s) . '</p>';
    echo '<p><strong>Transactions:</strong> ' . esc_html($t) . '</p>';
    echo '</div>';
}
function kbm_memberships_page(){ echo '<div class="wrap"><h1>Memberships</h1><p>Coming soon…</p></div>'; }
function kbm_subscriptions_page(){ echo '<div class="wrap"><h1>Subscriptions</h1><p>Coming soon…</p></div>'; }
function kbm_transactions_page(){ echo '<div class="wrap"><h1>Transactions</h1><p>Coming soon…</p></div>'; }
function kbm_settings_page(){ echo '<div class="wrap"><h1>Settings</h1><p>Coming soon…</p></div>'; }

// Shortcode: teaser
add_shortcode('kbm_restricted_notice', function(){
    return '<div class="kbm-restricted">' . esc_html__('You must be a member to view this content.', 'kwetu-bongo-membership') . '</div>';
});
