<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

delete_option('kbm_settings');
delete_option('kbm_version');
delete_site_option('kbm_settings');
delete_site_option('kbm_version');
